export class Aluno{

    aluno: string;
    nota1: number;
    nota2: number;
}