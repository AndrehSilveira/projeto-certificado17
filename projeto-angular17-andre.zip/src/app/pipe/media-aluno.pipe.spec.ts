import { MediaAlunoPipe } from './media-aluno.pipe';

describe('MediaAlunoPipe', () => {
  it('create an instance', () => {
    const pipe = new MediaAlunoPipe();
    expect(pipe).toBeTruthy();
  });
});
